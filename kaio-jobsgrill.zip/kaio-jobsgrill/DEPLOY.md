# 🔥 Deploy do Kaio no Vercel — Passo a Passo

## O que você vai precisar
- Conta no GitHub (gratuita) → github.com
- Conta no Vercel (gratuita) → vercel.com
- Sua API Key da Anthropic → console.anthropic.com

---

## PASSO 1 — Subir os arquivos no GitHub

1. Acesse **github.com** e clique em **"New repository"**
2. Nome sugerido: `kaio-jobsgrill`
3. Deixa **Public** ou **Private** (tanto faz)
4. Clica em **"Create repository"**

Agora suba os arquivos. Você tem 3 opções:

### Opção A — Pelo site do GitHub (mais fácil)
1. Na página do repositório criado, clique em **"uploading an existing file"**
2. Crie a estrutura de pastas:
   - Arraste o arquivo `vercel.json` para a raiz
   - Crie a pasta `api/` e arraste `chat.js`
   - Crie a pasta `public/` e arraste `index.html`
3. Clique em **"Commit changes"**

### Opção B — Pelo terminal (se souber usar)
```bash
git init
git add .
git commit -m "Kaio Jobs Grill - primeira versão"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/kaio-jobsgrill.git
git push -u origin main
```

---

## PASSO 2 — Conectar ao Vercel

1. Acesse **vercel.com** e faça login com sua conta GitHub
2. Clique em **"Add New Project"**
3. Selecione o repositório **kaio-jobsgrill**
4. Clique em **"Deploy"** (sem mexer em nada)

---

## PASSO 3 — Configurar a API Key (OBRIGATÓRIO)

Sem isso o Kaio não responde.

1. No painel do Vercel, abra seu projeto
2. Vá em **Settings → Environment Variables**
3. Clique em **"Add New"**
4. Preencha:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** sua chave (começa com `sk-ant-...`)
5. Clique em **"Save"**
6. Vá em **Deployments** e clique em **"Redeploy"** no deploy mais recente

---

## PASSO 4 — Pegar o link 🎉

Após o redeploy, o Vercel vai gerar um link assim:
```
https://kaio-jobsgrill.vercel.app
```

Esse é o link do Kaio. Pode compartilhar no WhatsApp, Instagram, Stories, Link na Bio — onde quiser.

---

## Como pegar sua API Key da Anthropic

1. Acesse **console.anthropic.com**
2. Faça login ou crie uma conta
3. Vá em **API Keys** no menu lateral
4. Clique em **"Create Key"**
5. Copie e salve — ela aparece só uma vez

> ⚠️ Nunca compartilhe sua API key com ninguém.
> Cada conversa do Kaio gasta alguns centavos de crédito. Monitore pelo console da Anthropic.

---

## Estrutura de arquivos do projeto

```
kaio-jobsgrill/
├── vercel.json          ← configuração de rotas
├── api/
│   └── chat.js          ← backend seguro (guarda a API key)
└── public/
    └── index.html       ← interface do Kaio
```

---

## Para o Instagram

- Coloca o link na **bio do perfil**
- Nos Stories: "Fala com o Kaio 👇" + link sticker
- No feed: "Link na bio pra tirar suas dúvidas com o Kaio 🔥"

---

## Dúvidas?

Se travar em algum passo, me chama que a gente resolve juntos! 🔥
